let pn;

function PNet(){
    this.call = function(){
    console.log("pn is called");   
    }
}
