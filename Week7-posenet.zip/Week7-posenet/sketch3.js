// this is a very simple sketch that demonstrates how to place a video cam image into a canvas 

let video;
let poses=[];
let img;

function setup(){
createCanvas(640, 480);
img = loadImage("images/nose.png")
video = createCapture(VIDEO);
video.size(width, height);
video.hide();
poseNet = ml5.poseNet(video, modelLoaded);
poseNet.on('pose', function(results) {
    poses = results;
  });}

function modelLoaded(){
    console.log("modelLoaded function has been called so this work!!!!");
};

function draw(){
    background(255)
    image(video, 0, 0);
    for (let i = 0; i < poses.length; i++) {
        // For each pose detected, loop through all the keypoints
        let pose = poses[i].pose;
        for (let j = 0; j < pose.keypoints.length; j++) {
          // A keypoint is an object describing a body part (like rightArm or leftShoulder)
          let keypoint = pose.keypoints[j];
          // Only draw an ellipse is the pose probability is bigger than 0.2
        //   console.log(keypoint.part)
          
          if (keypoint.score > 0.4 && keypoint.part=="nose") {
            // fill(255, 0, 0);
            // noStroke();
            push()
            imageMode(CENTER)
            image(img,keypoint.position.x, keypoint.position.y-50, 100, 100);
            pop()
          }
        }
      }
    
}